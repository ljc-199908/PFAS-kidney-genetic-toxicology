# Input data folder

Place the PFAS exposure instrument file here as:

```text
exposure_instruments.tsv
```

The file should contain one row per SNP-exposure association.

Required columns:

```text
exposure
SNP
beta.exposure
se.exposure
effect_allele.exposure
other_allele.exposure
eaf.exposure
pval.exposure
samplesize.exposure
```

Recommended values for `exposure`:

```text
PFOA
PFOS
```

The file can be generated from the SNP-level instrumental variable table reported in the manuscript/Supplementary Table S1.

Do not upload third-party full GWAS summary statistics or full harmonised datasets to this folder unless redistribution is explicitly permitted by the original data source.
